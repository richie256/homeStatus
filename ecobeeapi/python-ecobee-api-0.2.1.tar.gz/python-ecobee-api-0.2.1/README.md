# python-ecobee-api
A Python library for controlling Ecobee3 wifi thermostats.

## Notes
This is for use with [Home-Assistant](http://home-assistant.io)
